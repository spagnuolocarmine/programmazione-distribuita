/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package it.isislab;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author carminespagnuolo
 */
public class Client extends Thread{
    int responseMessage;
    int id;
    public Client(int id){
        this.id = id;
    }
    
    public static void main(String[] args) throws InterruptedException {
        int nTHs = 50;
        Client[] cs = new Client[nTHs];
        for (int i = 0; i < nTHs; i++) {
            cs[i] = new Client(i);
        }
        for (int i = 0; i < nTHs; i++) {
            cs[i].start();
        }
         for (int i = 0; i < nTHs; i++) {
            cs[i].join();
        }
         
        for (int i = 0; i < nTHs; i++) {
           for (int j = 0; j < nTHs; j++) {
               if (i !=j && cs[i].responseMessage == cs[j].responseMessage){
                   System.out.println("Error for threads "+cs[i].id+" "+cs[j].id+" values: "+cs[i].responseMessage+","+cs[j].responseMessage);
                   break;
               }
           }
        }
    }

    @Override
    public void run() {
       try {
            Registry registry = LocateRegistry.getRegistry();
            MessengerService server = (MessengerService) registry.lookup("MessengerService");
            responseMessage = server.sendMessage("Client Message");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
